
/**
 * Module dependencies.
 */
var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongodb');


var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://heroku_app23996090:gkgr3s0e3burf6l2m1i23pag21@ds043457.mongolab.com:43457/heroku_app23996090';


// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

// app.get('/', routes.index);
// app.get('/users', user.list);

app.get('/', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      // var d = col.find({}).toArray(function(err, x){
      //   console.log(x);
      // });
      page = '<!doctype html><html><head><title>2048 Scores!</title><style>body{ background-color: #FAF8EF; color: #776E65; font-family: "Clear Sans", "Helvetica Neue", Arial, sans-serif; } table, td, tr, th { border: 3px solid #BBADA0; border-collapse: collapse; } #board {table-layout: fixed; border: 7px solid #BBADA0; width: 390px; height: 390px; font-size: 42px;} </style></head><body><h1>2048 Game Center</h1>'
      col.find({}).sort("score").toArray(function(e, x){
        
        x = x.sort(function(a, b){
          return parseInt(b.score, 10)-parseInt(a.score, 10);
        });
        var tbl = "<table><tr><th>Name</th><th>Score</th><th>Time</th></tr>"
        if (x.length > 0) {
          for (var i = 0; i < x.length; i++){
            tbl += "<tr>" + "<td>" + x[i].username + "</td>" + "<td>" + x[i].score + "</td>" + "<td>" + x[i].created_at + "</td>" + "</tr>"
          }
          tbl += "</table>"
        } else {
          tbl = "<h2>No data yet. Try playing a game!</h2>"
        }
        page += tbl
        if (x.length > 0){ //If we have any data
          try {
            board = JSON.parse(x[0].grid);
            b = "<br /><h2>Best Board:</h2><br />"
            b += "<table id='board' style='text-align: center'>"
            if (board.cells.length == 4 && board.cells[0].length == 4) {
              for (var x = 0; x < 4; x++) {
                b += "<tr>"
                for (var y = 0; y < 4; y++) {
                  if (board["cells"][y][x].value == 2){
                    b += "<td style='background-color: #EEE4DA; color: #776E65; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 4){
                    b += "<td style='background-color: #EDE0C8; color: #776E65; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 8){
                    b += "<td style='background-color: #F2B179; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 16){
                    b += "<td style='background-color: #F59563; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 32){
                    b += "<td style='background-color: #F67C5F; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 64){
                    b += "<td style='background-color: #F65F3B; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 128){
                    b += "<td style='background-color: #EDCF72; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 256){
                    b += "<td style='background-color: #EDCC61; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 512){
                    b += "<td style='background-color: #EDC850; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else if (board["cells"][y][x].value == 1024){
                    b += "<td style='background-color: #EDC43D; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  } else {
                    b += "<td style='background-color: #EBC53F; color: #F9F6F2; border: 7px solid #BBADA0'>"
                  }
                  // page += JSON.stringify(board["cells"][y][x].value)
                  b += board["cells"][y][x].value + "</td>"
                }
                b += "</tr>"
              }
              b += "</table>"
              page += b;
            }
          } catch (e) {
            //Don't add board if it can't be made
            page += "<br /><h2>Malformed best board. Did you cheat?</h2>"
          }
        }
        

        page += '</body></html>'

        res.send(page); 
      });     
    });
  });
});

app.get('/scores.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      // var d = col.find({}).toArray(function(err, x){
      //   console.log(x);
      // });
      col.find({}).sort("score").toArray(function(e, x){
        x = x.sort(function(a, b){
          return parseInt(b.score, 10)-parseInt(a.score, 10);
        });
        res.send(x)
      });
    });
  });
});

app.post('/submit.json', function (req, res){
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){
      var score = escape(req.body.score);
      var username = escape(req.body.username);
      var grid = req.body.grid;
      var time = new Date()
      error = ""
      if (!score) {
        error += "No score provided\n"
      }
      if (!username) {
        error += "No username provided\n"
      }
      if (!grid) {
        error += "No grid provided\n"
      } 
      if (score && username && grid) {
        //Only add to the db when all of the information has been provided
        collection.insert({"score": score, "username": username, "grid": grid, "created_at": time}, function (err, r){});
        res.send("cool beans");
      } else {
        res.send(error);
      }
    });
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
